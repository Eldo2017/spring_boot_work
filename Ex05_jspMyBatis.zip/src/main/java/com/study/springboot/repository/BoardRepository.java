package com.study.springboot.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.study.springboot.domain.Board;

@Mapper
public interface BoardRepository {
	List<Board> list();
	Board detailBoard(String boardno);
	int totalRecord();
	int insertBoard(Board b);
	int deleteBoard(String boardno);
}
