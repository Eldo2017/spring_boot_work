package com.study.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.springboot.domain.Board;
import com.study.springboot.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardRepository bDao;
	
	@Override
	public List<Board> list() {
		return bDao.list();
	}

	@Override
	public Board detailBoard(String boardno) {
		return bDao.detailBoard(boardno);
	}

	@Override
	public int totalRecord() {
		return bDao.totalRecord();
	}

	@Override
	public int insertBoard(Board b) {
		return bDao.insertBoard(b);
	}

	@Override
	public int deleteBoard(String boardno) {
		return bDao.deleteBoard(boardno);
	}

}
